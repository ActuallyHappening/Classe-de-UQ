SELECT PostId, COUNT(*) FROM Comment GROUP BY Comment.PostId;
