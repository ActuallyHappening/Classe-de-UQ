SELECT User.Username FROM User WHERE
	0 = (SELECT COUNT(*) FROM UserFollows WHERE UserFollows.UserBeingFollowed = User.Username)